<?php

function validateEmail($email)
{
    $fileToCheckEmail = fopen('UserList.txt', "r");

    while (!feof($fileToCheckEmail))
    {
        $line = fgets($fileToCheckEmail);
        
        if (strpos($line, $email) !== false) 
        {
            echo 1;
        }
        else
        {
            echo 0;
        }
    }

    fclose($fileToCheckEmail);
}

function validateBusinessName($businessName)
{
    $fileToCheckBusinessName = fopen('UserList.txt', "r");

    while (!feof($fileToCheckBusinessName))
    {
        $data = fgets($fileToCheckBusinessName);
        
        if (strpos($data, $businessName) !== false) 
        {
            echo 1;
        }
        else
        {
            echo 0;
        }
    }

    fclose($fileToCheckBusinessName);
}

validateBusinessName("Lovely Akter");
validateEmail("My Own Business");

?>